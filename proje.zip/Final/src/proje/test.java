package proje;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class test extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField fld_userid;
    private JPasswordField fld_userpassword;
    private BinarySearchTree userTree;
    private String registeredUserId;
    private String registeredPassword;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    test frame = new test();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public test() {
        setResizable(false);
        setTitle("İ.E.Y Game Store");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 400);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(255, 255, 255));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JTabbedPane w_tabpane = new JTabbedPane(JTabbedPane.TOP);
        w_tabpane.setBounds(10, 146, 466, 207);
        contentPane.add(w_tabpane);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 255, 255));
        w_tabpane.addTab("Welcome !", null, panel, null);
        panel.setLayout(null);

        JLabel user_id = new JLabel("User ID :");
        user_id.setForeground(new Color(0, 0, 0));
        user_id.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
        user_id.setBounds(29, 15, 120, 47);
        panel.add(user_id);

        JLabel user_password = new JLabel("Password :\r\n");
        user_password.setForeground(new Color(0, 0, 0));
        user_password.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 20));
        user_password.setBounds(29, 61, 120, 47);
        panel.add(user_password);

        fld_userid = new JTextField();
        fld_userid.setFont(new Font("Yu Gothic UI Light", Font.BOLD, 15));
        fld_userid.setBounds(159, 27, 256, 26);
        panel.add(fld_userid);
        fld_userid.setColumns(10);

        JButton btn_login = new JButton("Login");
        btn_login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loginUser();
            }
        });
        btn_login.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btn_login.setBounds(135, 118, 90, 52);
        panel.add(btn_login);

        fld_userpassword = new JPasswordField();
        fld_userpassword.setBounds(158, 77, 257, 26);
        panel.add(fld_userpassword);

        JButton btn_register = new JButton("Register");
        btn_register.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        btn_register.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btn_register.setBounds(245, 118, 120, 52);
        panel.add(btn_register);

        JLabel lbl_logo = new JLabel(new ImageIcon(getClass().getResource("logomuz.png")));
        lbl_logo.setBounds(0, 0, 486, 150);
        contentPane.add(lbl_logo);

        // Initialize the binary search tree
        userTree = new BinarySearchTree();
    }

    private void registerUser() {
        String userId = fld_userid.getText();
        String password = new String(fld_userpassword.getPassword());

        
        if (userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a user ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

     
        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

       
        if (userTree.search(userId) != null) {
            JOptionPane.showMessageDialog(this, "This user already exists.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Store the registered user ID and password
        registeredUserId = userId;
        registeredPassword = password;

        // Create new user and insert into binary search tree
        User newUser = new User(userId, password);
        userTree.insert(newUser);

        JOptionPane.showMessageDialog(this, "User registered successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

        // Clear fields after registration
        fld_userid.setText("");
        fld_userpassword.setText("");
    }

    private void loginUser() {
        String userId = fld_userid.getText();
        String password = new String(fld_userpassword.getPassword());

        // Check if user ID and password match the registered ones
        if (userId.equals(registeredUserId) && password.equals(registeredPassword)) {
            JOptionPane.showMessageDialog(this, "Login successful. Welcome back, " + userId + "!", "Success", JOptionPane.INFORMATION_MESSAGE);
            // Open the second frame
            new second().setVisible(true);
            // Close the current frame
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid user ID or password.", "Error", JOptionPane.ERROR_MESSAGE);
            fld_userid.setText("");
            fld_userpassword.setText("");
        }
    }
}


