package proje;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.BorderLayout;
import javax.swing.DefaultComboBoxModel;

public class second extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel w_cpane;


  public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
          public void run() {
              try {
                  second frame = new second();
                  frame.setVisible(true);} catch (Exception e) {
                  e.printStackTrace();}}});}


  public second() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 647, 444);
      w_cpane = new JPanel();
      w_cpane.setToolTipText("");
      w_cpane.setBackground(new Color(255, 255, 255));
      w_cpane.setBorder(new EmptyBorder(5, 5, 5, 5));

      setContentPane(w_cpane);
      w_cpane.setLayout(null);
      JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
      tabbedPane.setBounds(0, 0, 0, 0);
      w_cpane.add(tabbedPane);
      JLabel lbl_logo2 = new JLabel(new ImageIcon(getClass().getResource("logomuz.png")));
      lbl_logo2.setBounds(5, 5, 623, 141);
      w_cpane.add(lbl_logo2);
      JComboBox comboBox = new JComboBox();
      comboBox.setModel(new DefaultComboBoxModel(new String[] {"ilhan", "yağız", "ege", }));
      comboBox.setBounds(282, 194, 121, 21);
      comboBox.setToolTipText("Please do choice");
      w_cpane.add(comboBox);}
}


