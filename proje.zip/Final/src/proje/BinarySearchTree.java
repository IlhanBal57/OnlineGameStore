package proje;

public class BinarySearchTree {

	private TreeNode root;
	private int size;
	
	public BinarySearchTree() {
		root = null;
		size = 0;
	}
	private TreeNode createNewNode(User user) {
		return new TreeNode(user);
	}
	public int getSize() {
		return size;
	}
	public TreeNode getRoot() {
		return root;
	}
	public boolean insert(User user) {
		if(root == null)
			root = createNewNode(user);
		else {
			TreeNode parent = null;
			TreeNode current = root;
			
			while (current != null) {
				int comparisonResult = user.getUserId().compareTo(current.getUser().getUserId());
				if(comparisonResult < 0) {
					parent = current;
					current = current.getLeft();
				}
				else if(comparisonResult > 0) {
					parent = current;
					current = current.getRight();
				}
				else
					return false;
			}
			
			if(user.getUserId().compareTo(parent.getUser().getUserId())< 0) {
				parent.setLeft(createNewNode(user));
			}
			else {
				parent.setRight(createNewNode(user));
			}
			size++;
			return true;
		}
		return false;
	}
	
	public User search(String userId) {
        TreeNode current = root;

        while (current != null) {
            int comparisonResult = userId.compareTo(current.getUser().getUserId());
            if (comparisonResult == 0) {
                
                return current.getUser();
            } else if (comparisonResult < 0) {
                current = current.getLeft();
            } else {
                current = current.getRight();
                }
        
        }
	
		return null;
	}
}
