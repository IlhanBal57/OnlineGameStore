package proje;

public class TreeNode {
	private User user;
	private TreeNode left;
	private TreeNode right;
	
	public TreeNode(User user) {
		this.user = user;
		left = null;
		right = null;
	}
	public User getUser()
	{
	 return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	public TreeNode getLeft() {
		return left;
	}
	
	public void setLeft(TreeNode left) {
		this.left = left;
	}
	public TreeNode getRight() {
		return right;
	}
	
	public void setRight(TreeNode right) {
		this.right = right;
	}
}
